import streamlit as st
import pickle
import numpy as np

st.set_page_config(
    page_title="News Article Classifier",
    page_icon="📰",
    layout="centered"
)

@st.cache_resource
def load_models():
    with open('tfidf_vectorizer.pkl', 'rb') as f:
        tfidf = pickle.load(f)
    with open('lr_model.pkl', 'rb') as f:
        model = pickle.load(f)
    with open('label_encoder.pkl', 'rb') as f:
        le = pickle.load(f)
    return tfidf, model, le

tfidf, model, le = load_models()

category_config = {
    'Politics':      {'emoji': '🏛️', 'color': '#1A2744'},
    'Entertainment': {'emoji': '🎬', 'color': '#0D9488'},
    'Wellness':      {'emoji': '🌿', 'color': '#7C3AED'},
    'Business':      {'emoji': '💼', 'color': '#F59E0B'},
    'Parenting':     {'emoji': '👨‍👩‍👧', 'color': '#EF4444'},
}

st.markdown("# 📰 News Article Classifier")
st.markdown("Type a news headline and the model will predict its category.")
st.markdown("---")

headline = st.text_input(
    "Enter a news headline:",
    placeholder="e.g. Trump signs new trade deal with China..."
)

st.markdown("**Try an example:**")
col1, col2, col3 = st.columns(3)
with col1:
    if st.button("🏛️ Politics"):
        headline = "Senate votes on new immigration reform bill"
with col2:
    if st.button("💼 Business"):
        headline = "Apple reports record quarterly revenue growth"
with col3:
    if st.button("🌿 Wellness"):
        headline = "New study reveals benefits of daily meditation"

col4, col5 = st.columns(2)
with col4:
    if st.button("🎬 Entertainment"):
        headline = "Oscar nominations announced for best picture"
with col5:
    if st.button("👨‍👩‍👧 Parenting"):
        headline = "How to help your child develop reading skills"

if headline:
    st.markdown("---")

    X          = tfidf.transform([headline])
    pred_idx   = model.predict(X)[0]
    pred_label = le.classes_[pred_idx]
    proba      = model.predict_proba(X)[0]

    cfg = category_config.get(pred_label, {'emoji': '📰', 'color': '#1A2744'})

    st.markdown(
        f"""
        <div style="
            background-color: {cfg['color']};
            padding: 20px 30px;
            border-radius: 12px;
            text-align: center;
            margin: 10px 0 20px 0;
        ">
            <div style="font-size: 48px;">{cfg['emoji']}</div>
            <div style="color: white; font-size: 14px; opacity: 0.8; margin-top: 4px;">
                Predicted Category
            </div>
            <div style="color: white; font-size: 32px; font-weight: bold;">
                {pred_label}
            </div>
        </div>
        """,
        unsafe_allow_html=True
    )

    st.markdown("### Confidence Scores")
    sorted_idx = np.argsort(proba)[::-1]

    for idx in sorted_idx:
        label = le.classes_[idx]
        prob  = proba[idx]
        cfg2  = category_config.get(label, {'emoji': '📰', 'color': '#1A2744'})

        col_label, col_bar, col_pct = st.columns([2, 5, 1])
        with col_label:
            st.markdown(f"{cfg2['emoji']} **{label}**")
        with col_bar:
            st.progress(float(prob))
        with col_pct:
            st.markdown(f"**{prob*100:.1f}%**")

    st.markdown("---")
    st.caption("Model: TF-IDF + Logistic Regression  |  Accuracy: 70.86%  |  Trained on HuffPost News Dataset")